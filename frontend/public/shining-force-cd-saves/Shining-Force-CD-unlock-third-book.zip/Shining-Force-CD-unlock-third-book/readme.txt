These files contain saves for Shining Force CD.

Internal-memory.brm - This contains SFCD_DAT_09 which controls which books are unlocked (1, 2, and 3 in this case)
RAM-cartridge.brm - This contains SFCD_DAT_01 and SFCD_DAT_02 which are saves at the end of books 1 and 2

Error correction is turned on for all 3 saves, which means the game is able to read them correctly. It also means they don't all fit into internal memory since SFCD_DAT_01 and SFCD_DAT_02 are 99 blocks each and internal memory is only 125 blocks. If you open the RAM cartridge file in a hex editor, you won't be able to read any character names in the data because it's all scrambled by the error correction. Check out https://github.com/euan-forrester/save-file-converter/blob/main/frontend/src/save-formats/SegaCd/SegaCd.js for more information on how the error correction works. 

To use these files in an emulator, you may need to resize RAM-cartridge.brm to be the size that your emulator expects.
Make a test save then look at the file size the emulator creates.
You can resize the file using https://savefileconverter.com/#/sega-cd
Then rename each file to be what the emulator expects, and you should be good to go.

To use them with a flash cart, you'll need to convert them using https://savefileconverter.com/#/flash-carts

And to use them with the MiSTer, you'll need to convert them using https://savefileconverter.com/#/mister
