This file contain saves for Shining Force CD.

Internal-memory.brm - This contains SFCD_DAT_09 which controls which books are unlocked (1, 2, and 3 in this case), and SFCD_DAT_01 and SFCD_DAT_02 which are saves at the end of books 1 and 2

Error correction is turned on for all SFCD_DAT_09, which means the game is able to read it correctly.
Error correction is turned off for SFCD_DAT_01 and SFCD_DAT_02 which means that they are half the size they normally are (50 blocks -- with error correction on they are 99 blocks) and can fit into the Sega CD's internal memory of 125 blocks. If you open the file with a hex editor you'll see the names of various characters, which you can't see when the error correction is turned on because the data gets scrambled. Check out https://github.com/euan-forrester/save-file-converter/blob/main/frontend/src/save-formats/SegaCd/SegaCd.js for more information on how the error correction works.

Unfortunately, although they contain the exact same data as when error correction is enabled, the game isn't able to read these versions of SFCD_DAT_01 and SFCD_DAT_02 correctly. When saves with error correction off are in internal memory the game just ignores them.
When saves with error correction off are on the RAM cartridge the game notices them but displays an error saying the data was lost.

So, unfortunately, even though we're able to fit all of the data into internal memory the game doesn't read it all correctly.
However, because SFCD_DAT_09 is stored with error correction on as the game expects, books 1, 2, and 3 are all unlocked.

To use this file in an emulator, flash cart, or MiSTer, just copy it to the right location and name it whatever the emulator/flash cart/MiSTer expects it to be.

You can also open this file using https://savefileconverter.com/#/sega-cd to extract or rearrange the saves inside, or move SFCD_DAT_01 and SFCD_DAT_02 to a RAM cartridge file.
